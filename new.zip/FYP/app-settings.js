const APP_TRANSLATIONS = {
    ms: {
        "Home": "Utama",
        "About": "Tentang",
        "Rooms": "Bilik",
        "Activities": "Aktiviti",
        "Contact": "Hubungi",
        "Login": "Log Masuk",
        "Student Hostel Portal": "Portal Asrama Pelajar",
        "Hostel Booking": "Tempahan Asrama",
        "Official booking portal for TVET MARA Besut students. Every room has 6 beds, and each student is only allowed to book 1 bed.": "Portal rasmi tempahan asrama untuk pelajar TVET MARA Besut. Setiap bilik mempunyai 6 katil, dan setiap pelajar hanya boleh menempah 1 katil.",
        "View Rooms": "Lihat Bilik",
        "See Activities": "Lihat Aktiviti",
        "Rooms Available": "Bilik Tersedia",
        "Beds per Room": "Katil Setiap Bilik",
        "Bed per Student": "Katil Setiap Pelajar",
        "About Hostel": "Tentang Asrama",
        "Student": "Pelajar",
        "Accommodation Rules": "Peraturan Penginapan",
        "This portal helps TVET MARA Besut students choose hostel rooms by block and book one bed quickly.": "Portal ini membantu pelajar TVET MARA Besut memilih bilik asrama mengikut blok dan menempah satu katil dengan mudah.",
        "6 Beds Per Room": "6 Katil Setiap Bilik",
        "All rooms in Block A, B and C have 6 beds in total.": "Semua bilik di Blok A, B dan C mempunyai 6 katil.",
        "1 Bed Per Student": "1 Katil Setiap Pelajar",
        "Each student is allowed to book only 1 bed to ensure fair allocation.": "Setiap pelajar hanya dibenarkan menempah 1 katil untuk memastikan pengagihan yang adil.",
        "No Price Charged": "Tiada Bayaran Dikenakan",
        "No payment or nightly price is shown in this system.": "Tiada bayaran atau harga malam dipaparkan dalam sistem ini.",
        "Fast Confirmation": "Pengesahan Pantas",
        "Submit your booking request and get confirmation from hostel management.": "Hantar permohonan tempahan dan dapatkan pengesahan daripada pengurusan asrama.",
        "Hostel Rooms": "Bilik Asrama",
        "View by": "Lihat Mengikut",
        "Block & Room": "Blok & Bilik",
        "Create a student account and login first before booking. Block eligibility is based on semester, council status and gender.": "Cipta akaun pelajar dan log masuk dahulu sebelum membuat tempahan. Kelayakan blok berdasarkan semester, status majlis pelajar dan jantina.",
        "All Blocks": "Semua Blok",
        "Block A": "Blok A",
        "Block B": "Blok B",
        "Block C": "Blok C",
        "Block A - Ground/Lower Floor": "Blok A - Tingkat Bawah",
        "Block A - Upper Floor": "Blok A - Tingkat Atas",
        "Block B - Ground/Lower Floor": "Blok B - Tingkat Bawah",
        "Block C - Female Block": "Blok C - Pelajar Perempuan",
        "Available Beds (Total Range)": "Katil Tersedia (Jumlah Julat)",
        "Login required to book": "Log masuk diperlukan untuk tempahan",
        "Female Students Only": "Pelajar Perempuan Sahaja",
        "Semester 2 - 5": "Semester 2 - 5",
        "Student Life": "Kehidupan Pelajar",
        "Hostel": "Asrama",
        "Activities": "Aktiviti",
        "Join campus and hostel programs to build community and improve student wellbeing.": "Sertai program kampus dan asrama untuk membina komuniti serta meningkatkan kesejahteraan pelajar.",
        "Join Event": "Sertai Aktiviti",
        "Hostel Office": "Pejabat Asrama",
        "Hostel Management": "Pengurusan Asrama",
        "For room booking support, contact TVET MARA Besut hostel administration.": "Untuk bantuan tempahan bilik, hubungi pentadbiran asrama TVET MARA Besut.",
        "Phone": "Telefon",
        "Email": "Emel",
        "Location": "Lokasi",
        "Name": "Nama",
        "Subject": "Subjek",
        "Message": "Mesej",
        "Send Message": "Hantar Mesej",
        "Quick Links": "Pautan Pantas",
        "Rules": "Peraturan",
        "Support": "Sokongan",
        "Student Verification": "Pengesahan Pelajar",
        "Hostel Guidelines": "Garis Panduan Asrama",
        "Admin Login": "Log Masuk Admin",
        "Login": "Log Masuk",
        "Register Account": "Daftar Akaun",
        "Sign In": "Log Masuk",
        "Register": "Daftar",
        "Create account": "Cipta akaun",
        "Full Name": "Nama Penuh",
        "Register As": "Daftar Sebagai",
        "Lecturer / Staff": "Pensyarah / Staf",
        "Semester": "Semester",
        "Gender": "Jantina",
        "Select gender": "Pilih jantina",
        "Male": "Lelaki",
        "Female": "Perempuan",
        "Student Council": "Majlis Perwakilan Pelajar",
        "Select semester": "Pilih semester",
        "Semester 1": "Semester 1",
        "Semester 2": "Semester 2",
        "Semester 3": "Semester 3",
        "Semester 4": "Semester 4",
        "Semester 5": "Semester 5",
        "No": "Tidak",
        "Yes": "Ya",
        "Password": "Kata Laluan",
        "Remember me": "Ingat saya",
        "Forgot password?": "Lupa kata laluan?",
        "Student Care & Complaint Portal": "Portal Aduan & Kebajikan Pelajar",
        "Submit issues quickly and track hostel maintenance updates in real-time.": "Hantar aduan dengan cepat dan jejak kemas kini penyelenggaraan asrama secara masa nyata.",
        "Back Home": "Kembali",
        "Logout": "Log Keluar",
        "Total Reports": "Jumlah Laporan",
        "New": "Baharu",
        "In Progress": "Dalam Proses",
        "Resolved": "Selesai",
        "Book Hostel Bed": "Tempah Katil Asrama",
        "Booking is available only after account creation and login.": "Tempahan hanya tersedia selepas akaun dicipta dan log masuk.",
        "Student Name": "Nama Pelajar",
        "Student ID": "ID Pelajar",
        "Eligible Block / Room Range": "Blok / Julat Bilik Layak",
        "Room Number": "Nombor Bilik",
        "Bed": "Katil",
        "Choose bed": "Pilih katil",
        "Check-in Date": "Tarikh Masuk",
        "Submit Booking": "Hantar Tempahan",
        "Block allocation rules:": "Peraturan penempatan blok:",
        "Block A:": "Blok A:",
        "Block B:": "Blok B:",
        "Block C:": "Blok C:",
        "Semester 1 students and Student Council.": "Pelajar Semester 1 dan Majlis Perwakilan Pelajar.",
        "Semester 2 - 5 students.": "Pelajar Semester 2 - 5.",
        "Female students only.": "Pelajar perempuan sahaja.",
        "The system also blocks duplicate bed selection and keeps the 1 bed per student rule.": "Sistem juga menghalang pilihan katil berganda dan mengekalkan peraturan 1 katil untuk setiap pelajar.",
        "Firestore collection:": "Koleksi Firestore:",
        "Contact Number (Optional)": "Nombor Telefon (Pilihan)",
        "Best Time to Contact (Optional)": "Masa Terbaik Untuk Dihubungi (Pilihan)",
        "Location Type": "Jenis Lokasi",
        "Room": "Bilik",
        "Bathroom": "Bilik Air",
        "Corridor": "Koridor",
        "Common Area": "Kawasan Umum",
        "Submit Complaint": "Hantar Aduan",
        "Recent Complaints": "Aduan Terkini",
        "All Status": "Semua Status",
        "All Priority": "Semua Keutamaan",
        "Priority": "Keutamaan",
        "High": "Tinggi",
        "Medium": "Sederhana",
        "Low": "Rendah",
        "Issue Category": "Kategori Isu",
        "Issue Details": "Butiran Isu",
        "Save Draft": "Simpan Draf",
        "Load Draft": "Muat Draf",
        "Clear Form": "Kosongkan Borang",
        "TVET MARA Staff Portal": "Portal Staf TVET MARA",
        "Dashboard": "Papan Pemuka",
        "Student Bookings": "Tempahan Pelajar",
        "Work Orders": "Arahan Kerja",
        "Reports": "Laporan",
        "Welcome back, Staff": "Selamat kembali, Staf",
        "Manage hostel operations and student requests.": "Urus operasi asrama dan permohonan pelajar.",
        "Total Students": "Jumlah Pelajar",
        "Available Beds": "Katil Tersedia",
        "Maintenance Issues": "Isu Penyelenggaraan",
        "Active Bookings": "Tempahan Aktif",
        "Portal Status": "Status Portal",
        "Online": "Dalam Talian",
        "Recent Check-in Requests": "Permohonan Daftar Masuk Terkini",
        "Actions": "Tindakan",
        "Theme": "Tema",
        "Language": "Bahasa",
        "Light": "Cerah",
        "Dark": "Gelap",
        "English": "English",
        "Malay": "Melayu"
    }
};

const APP_PLACEHOLDER_TRANSLATIONS = {
    ms: {
        "your full name": "nama penuh anda",
        "your NRIC number": "nombor NRIC anda",
        "your staff matrix number": "nombor matrik staf anda",
        "your email": "emel anda",
        "Your name": "Nama anda",
        "student@email.com": "pelajar@email.com",
        "How can hostel management help you?": "Bagaimana pengurusan asrama boleh membantu anda?",
        "Get hostel updates": "Dapatkan kemas kini asrama",
        "Example: A105": "Contoh: A105",
        "Search by ticket, room, issue, or details...": "Cari tiket, bilik, isu atau butiran...",
        "Explain the problem clearly...": "Terangkan masalah dengan jelas..."
    }
};

const APP_TEXT_NODES = [];

function injectPreferenceStyles() {
    if (document.getElementById('appPreferenceStyles')) return;

    const style = document.createElement('style');
    style.id = 'appPreferenceStyles';
    style.textContent = `
        .app-preferences {
            position: fixed;
            right: 18px;
            bottom: 18px;
            z-index: 3000;
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
            justify-content: flex-end;
            max-width: min(420px, calc(100vw - 36px));
        }
        .app-pref-btn {
            border: 1px solid rgba(148, 163, 184, 0.35);
            border-radius: 999px;
            padding: 0.62rem 0.82rem;
            background: rgba(255, 255, 255, 0.92);
            color: #0f172a;
            box-shadow: 0 10px 25px rgba(15, 23, 42, 0.16);
            cursor: pointer;
            font-weight: 800;
            font-family: inherit;
            backdrop-filter: blur(14px);
        }
        html[data-theme="dark"] {
            color-scheme: dark;
        }
        html[data-theme="dark"] body {
            background: #0f172a !important;
            color: #e5e7eb !important;
        }
        html[data-theme="dark"] .navbar.scrolled,
        html[data-theme="dark"] .nav-menu,
        html[data-theme="dark"] .card,
        html[data-theme="dark"] .feature-card,
        html[data-theme="dark"] .room-card,
        html[data-theme="dark"] .room-info,
        html[data-theme="dark"] .activity-card,
        html[data-theme="dark"] .contact-form-wrapper,
        html[data-theme="dark"] .modal-content,
        html[data-theme="dark"] .stat,
        html[data-theme="dark"] .stat-card,
        html[data-theme="dark"] .item,
        html[data-theme="dark"] .empty,
        html[data-theme="dark"] .main-content,
        html[data-theme="dark"] .top-bar {
            background: #1e293b !important;
            color: #e5e7eb !important;
            border-color: #334155 !important;
        }
        html[data-theme="dark"] .navbar {
            background: rgba(15, 23, 42, 0.72) !important;
            backdrop-filter: blur(20px);
        }
        html[data-theme="dark"] .nav-logo,
        html[data-theme="dark"] .floating-card {
            color: #f8fafc !important;
        }
        html[data-theme="dark"] .floating-card {
            background: #1e293b !important;
            border: 1px solid #334155 !important;
        }
        html[data-theme="dark"] .hero-stats .stat {
            background: rgba(30, 41, 59, 0.86) !important;
            border: 1px solid #334155 !important;
            border-radius: 0.75rem;
            padding: 0.85rem 1rem;
        }
        html[data-theme="dark"] .stat-number {
            color: #f8fafc !important;
        }
        html[data-theme="dark"] .about,
        html[data-theme="dark"] .rooms,
        html[data-theme="dark"] .activities,
        html[data-theme="dark"] .contact,
        html[data-theme="dark"] .footer,
        html[data-theme="dark"] .section,
        html[data-theme="dark"] .admin-container {
            background: #0f172a !important;
            color: #e5e7eb !important;
        }
        html[data-theme="dark"] input,
        html[data-theme="dark"] select,
        html[data-theme="dark"] textarea,
        html[data-theme="dark"] .filter-btn,
        html[data-theme="dark"] .btn-social,
        html[data-theme="dark"] .price-summary {
            background: #0f172a !important;
            color: #e5e7eb !important;
            border-color: #475569 !important;
        }
        html[data-theme="dark"] .muted,
        html[data-theme="dark"] .item-sub,
        html[data-theme="dark"] .stat-label,
        html[data-theme="dark"] .room-info p,
        html[data-theme="dark"] .room-features span,
        html[data-theme="dark"] .section-header p,
        html[data-theme="dark"] .hero p,
        html[data-theme="dark"] .feature-card p,
        html[data-theme="dark"] .activity-meta,
        html[data-theme="dark"] .activity-details > p,
        html[data-theme="dark"] .contact-info > p,
        html[data-theme="dark"] .contact-item p,
        html[data-theme="dark"] .modal-header p,
        html[data-theme="dark"] .checkbox,
        html[data-theme="dark"] .auth-divider,
        html[data-theme="dark"] .auth-switch,
        html[data-theme="dark"] .toggle-text,
        html[data-theme="dark"] .booking-note,
        html[data-theme="dark"] .note {
            color: #cbd5e1 !important;
        }
        html[data-theme="dark"] .btn-secondary {
            color: #f8fafc !important;
            border-color: #475569 !important;
            background: rgba(30, 41, 59, 0.78) !important;
        }
        html[data-theme="dark"] .contact-item i,
        html[data-theme="dark"] .social-links a,
        html[data-theme="dark"] .activity-image,
        html[data-theme="dark"] .close {
            background: #0f172a !important;
            color: #a5b4fc !important;
        }
        html[data-theme="dark"] .auth-divider::before,
        html[data-theme="dark"] .auth-divider::after,
        html[data-theme="dark"] .room-footer,
        html[data-theme="dark"] .price-row.total {
            border-color: #475569 !important;
        }
        html[data-theme="dark"] .nav-menu a,
        html[data-theme="dark"] h1,
        html[data-theme="dark"] h2,
        html[data-theme="dark"] h3,
        html[data-theme="dark"] h4 {
            color: #f8fafc !important;
        }
        html[data-theme="dark"] .app-pref-btn {
            background: rgba(30, 41, 59, 0.94);
            color: #f8fafc;
            border-color: #475569;
        }
        @media (max-width: 640px) {
            .app-preferences {
                left: 12px;
                right: 12px;
                bottom: 12px;
            }
            .app-pref-btn {
                flex: 1;
            }
        }
    `;
    document.head.appendChild(style);
}

function createPreferenceControls() {
    if (document.querySelector('.app-preferences')) return;

    const wrapper = document.createElement('div');
    wrapper.className = 'app-preferences';
    wrapper.innerHTML = `
        <button type="button" class="app-pref-btn" id="themeToggle"></button>
        <button type="button" class="app-pref-btn" id="languageToggle"></button>
    `;
    document.body.appendChild(wrapper);

    document.getElementById('themeToggle').addEventListener('click', () => {
        const nextTheme = getPreference('theme', 'light') === 'dark' ? 'light' : 'dark';
        setPreference('theme', nextTheme);
        applyPreferences();
    });

    document.getElementById('languageToggle').addEventListener('click', () => {
        const nextLanguage = getPreference('language', 'en') === 'ms' ? 'en' : 'ms';
        setPreference('language', nextLanguage);
        applyPreferences();
    });
}

function getPreference(key, fallback) {
    return localStorage.getItem(`shmaas_${key}`) || fallback;
}

function setPreference(key, value) {
    localStorage.setItem(`shmaas_${key}`, value);
}

function rememberOriginals() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
            const parent = node.parentElement;
            if (!parent || ['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(parent.tagName)) {
                return NodeFilter.FILTER_REJECT;
            }
            return node.nodeValue.trim() ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        }
    });

    const nodes = [];
    while (walker.nextNode()) {
        nodes.push(walker.currentNode);
    }

    nodes.forEach(node => {
        if (!APP_TEXT_NODES.some(entry => entry.node === node)) {
            APP_TEXT_NODES.push({
                node,
                original: node.nodeValue
            });
        }
    });

    document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach(element => {
        if (!element.dataset.originalPlaceholder) {
            element.dataset.originalPlaceholder = element.getAttribute('placeholder');
        }
    });
}

function translatePage(language) {
    const dictionary = APP_TRANSLATIONS[language] || {};
    const placeholderDictionary = APP_PLACEHOLDER_TRANSLATIONS[language] || {};

    APP_TEXT_NODES.forEach(entry => {
        const trimmedOriginal = entry.original.trim();
        const translated = language === 'en' ? trimmedOriginal : dictionary[trimmedOriginal];
        if (translated) {
            const leading = entry.original.match(/^\s*/)?.[0] || '';
            const trailing = entry.original.match(/\s*$/)?.[0] || '';
            entry.node.nodeValue = `${leading}${translated}${trailing}`;
        } else {
            entry.node.nodeValue = entry.original;
        }
    });

    document.querySelectorAll('[data-original-placeholder]').forEach(element => {
        const original = element.dataset.originalPlaceholder;
        const translated = language === 'en' ? original : placeholderDictionary[original];
        element.setAttribute('placeholder', translated || original);
    });
}

function updatePreferenceLabels() {
    const theme = getPreference('theme', 'light');
    const language = getPreference('language', 'en');
    const themeToggle = document.getElementById('themeToggle');
    const languageToggle = document.getElementById('languageToggle');

    if (themeToggle) {
        themeToggle.textContent = theme === 'dark'
            ? (language === 'ms' ? '☀️ Tema Cerah' : '☀️ Light Theme')
            : (language === 'ms' ? '🌙 Tema Gelap' : '🌙 Dark Theme');
    }

    if (languageToggle) {
        languageToggle.textContent = language === 'ms' ? '🇬🇧 English' : '🇲🇾 Melayu';
    }
}

function applyPreferences() {
    const theme = getPreference('theme', 'light');
    const language = getPreference('language', 'en');

    document.documentElement.dataset.theme = theme;
    document.documentElement.lang = language === 'ms' ? 'ms' : 'en';
    rememberOriginals();
    translatePage(language);
    updatePreferenceLabels();
}

document.addEventListener('DOMContentLoaded', () => {
    injectPreferenceStyles();
    createPreferenceControls();
    applyPreferences();
});
